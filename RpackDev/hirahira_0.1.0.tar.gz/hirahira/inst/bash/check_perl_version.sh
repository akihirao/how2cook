#!bin/bash
# check_perl_version.sh

perl --version
