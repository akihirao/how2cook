#!/bin/bash
# check_os.sh

uname
