test_that("Identification of a reverse-complement sequence", {
  seq <- "ATGC"
  exp_seq_rc <- "GCAT"
  expect_identical(RevCompSeq(seq), exp_seq_rc)
})
