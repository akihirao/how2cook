#include <Rcpp.h>
using namespace Rcpp;


//' 数を２倍する
//'
//' @param x 1つの整数
//' @export
// [[Rcpp::export]]
int timesTwo(int x) {
  return x * 2;
}
