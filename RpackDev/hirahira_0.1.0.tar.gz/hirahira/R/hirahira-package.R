#' @useDynLib hirahira, .registration=TRUE
#' @importFrom Rcpp sourceCpp
NULL
