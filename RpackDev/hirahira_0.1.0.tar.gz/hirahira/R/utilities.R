#' Generation of a reverse-complement sequence
#'
#' @param seq 塩基配列（"ATGC"など）
#'
#' @return a reverse-complement sequence
#' @export
#'
#' @examples
#' seq <- "ATGC"
#' seq_rc <- RevCompSeq(seq)
RevCompSeq <- function(seq) {
  seq_rev <- sapply(lapply(strsplit(seq, NULL), rev), paste, collapse="")
  seq_rev_comp <- chartr("ACGT", "TGCA",seq_rev)
  return(seq_rev_comp)
}
