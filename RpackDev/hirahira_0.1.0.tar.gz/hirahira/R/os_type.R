##' Example of calling a script via system
##'
os_type <- function() {
  path <- system.file("bash", "check_os.sh", package="hirahira")
  cmd <- paste("bash", path)
  res <- readLines(pipe(cmd))
  return(res)
}
