#' Perl言語からの"Hello World!"
#'
#' @return "Hello, Python World!"
#' @export
#'
#' @examples
#' say_hello_py()
say_hello_py <- function(){

  #各自のpython環境に合わせてパスを設定すること!
  path_py <- "/Users/akihirao/opt/miniconda3/bin/python"

  path_hello_py <- system.file("python", "hello.py", package="hirahira")

  system(paste0(path_py, " ", path_hello_py))
}
