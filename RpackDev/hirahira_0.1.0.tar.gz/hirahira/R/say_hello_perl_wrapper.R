#' Perl言語からの"Hello World!"
#'
#' @return "Hello, Perl World!"
#' @export
#'
#' @examples
#' say_hello_pl()
say_hello_pl <- function(){
  path_hello_pl <- system.file("perl", "hello.pl", package="hirahira")
  system(paste0("perl", " ", path_hello_pl))
}
