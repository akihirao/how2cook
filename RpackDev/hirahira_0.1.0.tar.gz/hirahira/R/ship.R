##' Example of calling a script via system
##'
otherViaSystem <- function() {
  path <- system.file("bash", "silly.sh", package="hirahira")
  cmd <- paste("sh", path)
  res <- utils::read.csv(pipe(cmd))
}
