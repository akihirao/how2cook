#' Perl versionの確認：Example of calling a script via system
#'
#' @return "Perl versonの表示
#' @export
#'
#' @examples
#' show_perl_version()
show_perl_version <- function() {
  path <- system.file("bash", "check_perl_version.sh", package="hirahira")
  cmd <- paste("bash", path)
  res <- readLines(pipe(cmd))
  return(res)
}
