#' Perlのversionの確認
#'
#' @return Perl version
#' @export
#'
#' @examples
#' show_perl_version()
show_perl_version <- function() {
  path <- system.file("bash", "check_perl_version.sh", package="hirahira")
  cmd <- paste("bash", path)
  res <- readLines(pipe(cmd))
  out <- res[[2]]
  return(out)
}
